package com.myra.assistant.ai

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.sqrt

/**
 * Handles raw PCM mic capture (16kHz) and speaker playback (24kHz) exactly like the
 * Python `sounddevice` reference implementation: fixed 1024-byte chunks, echo suppression
 * while MYRA speaks, and a playback queue that can be cleared on interrupt.
 */
class AudioEngine(private val context: Context) {

    companion object {
        private const val TAG = "AudioEngine"
        const val MIC_SAMPLE_RATE = 16000
        const val SPEAKER_SAMPLE_RATE = 24000
        const val CHUNK_SIZE = 1024
    }

    var onMicChunk: ((ByteArray) -> Unit)? = null
    var onAmplitudeChanged: ((Float) -> Unit)? = null
    var onSpeakingStarted: (() -> Unit)? = null
    var onSpeakingStopped: (() -> Unit)? = null

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var recordJob: Job? = null
    private var playbackJob: Job? = null

    private val playbackQueue = ConcurrentLinkedQueue<ByteArray>()
    private var isMuted = false
    private var isSpeaking = false
    private var isRecording = false

    @SuppressLint("MissingPermission")
    fun startRecording() {
        if (isRecording) return
        val minBuf = AudioRecord.getMinBufferSize(
            MIC_SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuf, CHUNK_SIZE * 4)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MIC_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            Log.e(TAG, "AudioRecord failed to initialize")
            return
        }

        audioRecord?.startRecording()
        isRecording = true

        recordJob = scope.launch {
            val buffer = ByteArray(CHUNK_SIZE)
            while (isActive && isRecording) {
                val read = audioRecord?.read(buffer, 0, CHUNK_SIZE) ?: -1
                if (read > 0) {
                    val chunk = buffer.copyOf(read)
                    val rms = calculateRms(chunk)
                    withContext(Dispatchers.Main) { onAmplitudeChanged?.invoke(rms) }

                    // Echo suppression: don't send mic audio while MYRA is speaking, and honor mute
                    if (!isSpeaking && !isMuted) {
                        onMicChunk?.invoke(chunk)
                    }
                }
            }
        }
    }

    fun stopRecording() {
        isRecording = false
        recordJob?.cancel()
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
    }

    fun startPlayback() {
        val minBuf = AudioTrack.getMinBufferSize(
            SPEAKER_SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = maxOf(minBuf, CHUNK_SIZE * 4)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()

        val format = AudioFormat.Builder()
            .setSampleRate(SPEAKER_SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .build()

        audioTrack = AudioTrack(
            attrs, format, bufferSize, AudioTrack.MODE_STREAM, AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        audioTrack?.play()

        playbackJob = scope.launch {
            while (isActive) {
                val chunk = playbackQueue.poll()
                if (chunk != null) {
                    if (!isSpeaking) {
                        isSpeaking = true
                        withContext(Dispatchers.Main) { onSpeakingStarted?.invoke() }
                    }
                    audioTrack?.write(chunk, 0, chunk.size)
                } else {
                    if (isSpeaking) {
                        // Small grace delay in case more chunks are still in flight
                        delay(250)
                        if (playbackQueue.isEmpty()) {
                            isSpeaking = false
                            withContext(Dispatchers.Main) { onSpeakingStopped?.invoke() }
                        }
                    } else {
                        delay(30)
                    }
                }
            }
        }
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
        playbackQueue.clear()
    }

    /** Queue a chunk of 24kHz PCM audio received from Gemini for playback. */
    fun queueAudio(pcmBytes: ByteArray) {
        playbackQueue.add(pcmBytes)
    }

    /** Long-press mic: stop MYRA speaking immediately and clear pending audio. */
    fun clearPlaybackQueue() {
        playbackQueue.clear()
        isSpeaking = false
        onSpeakingStopped?.invoke()
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    fun isMuted(): Boolean = isMuted
    fun isCurrentlySpeaking(): Boolean = isSpeaking

    private fun calculateRms(chunk: ByteArray): Float {
        if (chunk.isEmpty()) return 0f
        var sum = 0.0
        var i = 0
        while (i < chunk.size - 1) {
            val sample = ((chunk[i + 1].toInt() shl 8) or (chunk[i].toInt() and 0xFF)).toShort()
            sum += sample * sample
            i += 2
        }
        val samples = chunk.size / 2
        if (samples == 0) return 0f
        val rms = sqrt(sum / samples)
        return (rms / 32768.0).toFloat().coerceIn(0f, 1f)
    }

    fun release() {
        stopRecording()
        stopPlayback()
        scope.cancel()
    }
}
