package com.myra.assistant.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.TelecomManager
import androidx.core.app.ActivityCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myra.assistant.model.AppCommand
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.service.AccessibilityHelperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private val APP_PACKAGE_MAP = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "facebook" to "com.facebook.katana",
            "chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "spotify" to "com.spotify.music",
            "netflix" to "com.netflix.mediaclient",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "telegram" to "org.telegram.messenger",
            "snapchat" to "com.snapchat.android",
            "settings" to "com.android.settings",
            "calculator" to "com.android.calculator2",
            "calendar" to "com.google.android.calendar",
            "clock" to "com.android.deskclock",
            "phone" to "com.android.dialer",
            "contacts" to "com.android.contacts",
            "play store" to "com.android.vending",
            "amazon" to "in.amazon.mShop.android.shopping",
            "flipkart" to "com.flipkart.android",
            "paytm" to "net.one97.paytm",
            "phonepe" to "com.phonepe.app",
            "gpay" to "com.google.android.apps.nbu.paisa.user",
            "zoom" to "us.zoom.videomeetings",
            "meet" to "com.google.android.apps.tachyon",
            "teams" to "com.microsoft.teams",
            "tiktok" to "com.zhiliaoapp.musically",
            "discord" to "com.discord",
            "linkedin" to "com.linkedin.android"
        )
    }

    private val prefs = application.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)

    private val _commandResult = MutableLiveData<String?>()
    val commandResult: LiveData<String?> = _commandResult

    fun execute(command: AppCommand) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = when (command.type) {
                AppCommand.OPEN_APP -> openApp(command.params["app_name"].orEmpty())
                AppCommand.CLOSE_APP -> closeApp()
                AppCommand.CALL -> makeCall(command.params["name"].orEmpty())
                AppCommand.SMS -> sendSms(command.params["name"].orEmpty(), command.params["message"].orEmpty())
                AppCommand.WHATSAPP_MSG -> whatsAppMessage(command.params["name"].orEmpty(), command.params["message"].orEmpty())
                AppCommand.WHATSAPP_CALL -> whatsAppMessage(command.params["name"].orEmpty(), "")
                AppCommand.PRIME_CALL -> primeCall(command.params["index"]?.toIntOrNull() ?: 0)
                AppCommand.PRIME_MSG -> primeMessage(command.params["index"]?.toIntOrNull() ?: 0)
                AppCommand.VOLUME_UP -> adjustVolume(true)
                AppCommand.VOLUME_DOWN -> adjustVolume(false)
                AppCommand.FLASHLIGHT_ON -> setFlashlight(true)
                AppCommand.FLASHLIGHT_OFF -> setFlashlight(false)
                AppCommand.WIFI_ON -> "WiFi settings khol rahi hoon."
                AppCommand.WIFI_OFF -> "WiFi settings khol rahi hoon."
                AppCommand.BLUETOOTH_ON -> "Bluetooth settings khol rahi hoon."
                AppCommand.BLUETOOTH_OFF -> "Bluetooth settings khol rahi hoon."
                AppCommand.ACCEPT_CALL -> acceptCall()
                AppCommand.REJECT_CALL -> rejectCall()
                else -> null
            }
            _commandResult.postValue(result)
        }
    }

    // ---------- App open/close ----------

    private fun openApp(appNameRaw: String): String {
        val appName = appNameRaw.trim().lowercase()
        if (appName.isBlank()) return "App ka naam samajh nahi aaya."

        val pm = getApplication<Application>().packageManager
        val packageName = APP_PACKAGE_MAP[appName]

        val launchIntent = if (packageName != null) {
            pm.getLaunchIntentForPackage(packageName)
        } else {
            // Fallback: scan installed apps by label
            findPackageByLabel(pm, appName)?.let { pm.getLaunchIntentForPackage(it) }
        }

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            getApplication<Application>().startActivity(launchIntent)
            "$appNameRaw khol diya."
        } else {
            "$appNameRaw install nahi mila."
        }
    }

    private fun findPackageByLabel(pm: PackageManager, label: String): String? {
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (appInfo in apps) {
            val appLabel = pm.getApplicationLabel(appInfo).toString().lowercase()
            if (appLabel.contains(label) || label.contains(appLabel)) {
                return appInfo.packageName
            }
        }
        return null
    }

    private fun closeApp(): String {
        val service = AccessibilityHelperService.instance
        return if (service != null) {
            service.closeCurrentApp()
            "App band kar diya."
        } else {
            "Accessibility service on nahi hai."
        }
    }

    // ---------- Calls / SMS / WhatsApp ----------

    private fun makeCall(name: String): String {
        val number = resolveContactNumber(name) ?: return "$name ka number nahi mila."
        return placeCall(number, name)
    }

    private fun placeCall(number: String, label: String): String {
        if (ActivityCompat.checkSelfPermission(getApplication(), android.Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED
        ) return "Call permission nahi hai."

        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(intent)
        return "$label ko call kar rahi hoon."
    }

    private fun sendSms(name: String, message: String): String {
        val number = resolveContactNumber(name) ?: return "$name ka number nahi mila."
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("smsto:$number")).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(intent)
        return "$name ko message bhej rahi hoon."
    }

    private fun whatsAppMessage(name: String, message: String): String {
        val number = resolveContactNumber(name) ?: return "$name ka number nahi mila."
        val encoded = Uri.encode(message)
        val cleanNumber = number.filter { it.isDigit() || it == '+' }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanNumber?text=$encoded")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        getApplication<Application>().startActivity(intent)
        return "$name ko WhatsApp kar rahi hoon."
    }

    private fun resolveContactNumber(name: String): String? {
        if (name.isBlank()) return null
        if (ActivityCompat.checkSelfPermission(getApplication(), android.Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null

        val resolver = getApplication<Application>().contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIdx = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIdx)
            }
        }
        return null
    }

    // ---------- Prime contacts ----------

    fun getPrimeContacts(): List<PrimeContact> {
        val json = prefs.getString("prime_contacts_json", null)
        if (json != null) {
            val list = mutableListOf<PrimeContact>()
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(PrimeContact(obj.getString("name"), obj.getString("number")))
            }
            return list
        }
        // Legacy migration
        val legacyName = prefs.getString("prime_name", null)
        val legacyNumber = prefs.getString("prime_number", null)
        return if (legacyName != null && legacyNumber != null) {
            listOf(PrimeContact(legacyName, legacyNumber))
        } else emptyList()
    }

    fun savePrimeContacts(contacts: List<PrimeContact>) {
        val arr = JSONArray()
        contacts.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name)
                put("number", it.number)
            })
        }
        prefs.edit().putString("prime_contacts_json", arr.toString()).apply()
    }

    private fun primeCall(index: Int): String {
        val contacts = getPrimeContacts()
        val contact = contacts.getOrNull(index) ?: return "Prime contact set nahi hai."
        return placeCall(contact.number, contact.name)
    }

    private fun primeMessage(index: Int): String {
        val contacts = getPrimeContacts()
        val contact = contacts.getOrNull(index) ?: return "Prime contact set nahi hai."
        return whatsAppMessage(contact.name, "")
    }

    // ---------- Volume / Flashlight ----------

    private fun adjustVolume(up: Boolean): String {
        val audioManager = getApplication<Application>()
            .getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val direction = if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, direction, android.media.AudioManager.FLAG_SHOW_UI)
        return if (up) "Volume badha diya." else "Volume kam kar diya."
    }

    private fun setFlashlight(on: Boolean): String {
        return try {
            val cameraManager = getApplication<Application>().getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return "Flashlight support nahi hai."
            cameraManager.setTorchMode(cameraId, on)
            if (on) "Torch on kar diya." else "Torch off kar diya."
        } catch (e: Exception) {
            "Torch control nahi ho paya."
        }
    }

    // ---------- Call accept/reject ----------

    fun acceptCall(): String {
        return try {
            val tm = getApplication<Application>().getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (ActivityCompat.checkSelfPermission(getApplication(), android.Manifest.permission.ANSWER_PHONE_CALLS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                tm.acceptRingingCall()
                "Call accept kar diya."
            } else "Call answer permission nahi hai."
        } catch (e: Exception) {
            "Call accept nahi ho paya."
        }
    }

    fun rejectCall(): String {
        return try {
            val tm = getApplication<Application>().getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            if (ActivityCompat.checkSelfPermission(getApplication(), android.Manifest.permission.ANSWER_PHONE_CALLS)
                == PackageManager.PERMISSION_GRANTED
            ) {
                tm.endCall()
                "Call reject kar diya."
            } else "Call control permission nahi hai."
        } catch (e: Exception) {
            "Call reject nahi ho paya."
        }
    }
}
