package com.myra.assistant.model

/**
 * Represents a parsed voice command that MYRA should execute on the device.
 * [type] is one of the CommandType constants below.
 * [params] carries any extra data the executor needs (app_name, contact name, message body, etc).
 */
data class AppCommand(
    val type: String,
    val params: Map<String, String> = emptyMap()
) {
    companion object CommandType {
        const val OPEN_APP = "OPEN_APP"
        const val CLOSE_APP = "CLOSE_APP"
        const val CALL = "CALL"
        const val SMS = "SMS"
        const val WHATSAPP_MSG = "WHATSAPP_MSG"
        const val WHATSAPP_CALL = "WHATSAPP_CALL"
        const val PRIME_CALL = "PRIME_CALL"
        const val PRIME_MSG = "PRIME_MSG"
        const val VOLUME_UP = "VOLUME_UP"
        const val VOLUME_DOWN = "VOLUME_DOWN"
        const val FLASHLIGHT_ON = "FLASHLIGHT_ON"
        const val FLASHLIGHT_OFF = "FLASHLIGHT_OFF"
        const val WIFI_ON = "WIFI_ON"
        const val WIFI_OFF = "WIFI_OFF"
        const val BLUETOOTH_ON = "BLUETOOTH_ON"
        const val BLUETOOTH_OFF = "BLUETOOTH_OFF"
        const val ACCEPT_CALL = "ACCEPT_CALL"
        const val REJECT_CALL = "REJECT_CALL"
    }
}

/** A single line of chat shown in the transcript RecyclerView. */
data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

/** One saved "prime" contact (close friend / partner / family shortcut). */
data class PrimeContact(
    val name: String,
    val number: String
)
