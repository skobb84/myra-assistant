package com.myra.assistant.ai

import com.myra.assistant.model.AppCommand

/**
 * Parses transcribed speech (Hinglish or English) into an [AppCommand].
 * Returns null when no local command matches, so the caller can let Gemini
 * handle the utterance as plain conversation instead.
 */
object CommandParser {

    private val APP_OPEN_WORDS = listOf("kholo", "khol do", "open", "start karo", "chalao")
    private val APP_CLOSE_WORDS = listOf("band karo", "close", "band kar do", "band")
    private val CALL_WORDS = listOf("call karo", "call kar do", "ko call karo", "call ")
    private val SMS_WORDS = listOf("sms bhejo", "message bhejo", "text karo", "sms karo")
    private val WHATSAPP_WORDS = listOf("whatsapp karo", "whatsapp bhejo", "whatsapp msg", "whatsapp message")
    private val PRIME_WORDS = listOf(
        "close friend", "meri jaan", "mera pyaar", "my love", "prime contact", "special contact"
    )

    fun parse(rawText: String): AppCommand? {
        val text = rawText.trim().lowercase()
        if (text.isBlank()) return null

        // Prime contact index e.g. "second contact", "third prime contact"
        val primeIndex = extractPrimeIndex(text)

        // PRIME_CALL / PRIME_MSG (checked before generic call/msg)
        if (PRIME_WORDS.any { text.contains(it) }) {
            return if (text.contains("msg") || text.contains("message") || text.contains("sms")) {
                AppCommand(AppCommand.PRIME_MSG, mapOf("index" to primeIndex.toString()))
            } else {
                AppCommand(AppCommand.PRIME_CALL, mapOf("index" to primeIndex.toString()))
            }
        }

        // Volume
        if (text.contains("volume badhao") || text.contains("volume up") || text.contains("volume increase")) {
            return AppCommand(AppCommand.VOLUME_UP)
        }
        if (text.contains("volume kam karo") || text.contains("volume down") || text.contains("volume decrease")) {
            return AppCommand(AppCommand.VOLUME_DOWN)
        }

        // Flashlight
        if ((text.contains("torch") || text.contains("flashlight")) && text.contains("on")) {
            return AppCommand(AppCommand.FLASHLIGHT_ON)
        }
        if ((text.contains("torch") || text.contains("flashlight")) && (text.contains("off") || text.contains("band"))) {
            return AppCommand(AppCommand.FLASHLIGHT_OFF)
        }

        // WiFi
        if (text.contains("wifi") && text.contains("on")) return AppCommand(AppCommand.WIFI_ON)
        if (text.contains("wifi") && (text.contains("off") || text.contains("band"))) return AppCommand(AppCommand.WIFI_OFF)

        // Bluetooth
        if (text.contains("bluetooth") && text.contains("on")) return AppCommand(AppCommand.BLUETOOTH_ON)
        if (text.contains("bluetooth") && (text.contains("off") || text.contains("band"))) return AppCommand(AppCommand.BLUETOOTH_OFF)

        // WhatsApp call vs message
        if (WHATSAPP_WORDS.any { text.contains(it) }) {
            val name = extractName(text, WHATSAPP_WORDS)
            return if (text.contains("call")) {
                AppCommand(AppCommand.WHATSAPP_CALL, mapOf("name" to name))
            } else {
                AppCommand(AppCommand.WHATSAPP_MSG, mapOf("name" to name, "message" to extractMessageBody(text)))
            }
        }

        // SMS
        if (SMS_WORDS.any { text.contains(it) }) {
            val name = extractName(text, SMS_WORDS)
            return AppCommand(AppCommand.SMS, mapOf("name" to name, "message" to extractMessageBody(text)))
        }

        // Generic call: "[name] ko call karo" / "call [name]"
        if (CALL_WORDS.any { text.contains(it) }) {
            val name = extractName(text, CALL_WORDS)
            if (name.isNotBlank()) {
                return AppCommand(AppCommand.CALL, mapOf("name" to name))
            }
        }

        // Close app: check before open, since "band karo" is distinct
        if (APP_CLOSE_WORDS.any { text.contains(it) }) {
            val appName = extractAppName(text, APP_CLOSE_WORDS)
            if (appName.isNotBlank()) {
                return AppCommand(AppCommand.CLOSE_APP, mapOf("app_name" to appName))
            }
        }

        // Open app: "YouTube kholo" / "open YouTube"
        if (APP_OPEN_WORDS.any { text.contains(it) }) {
            val appName = extractAppName(text, APP_OPEN_WORDS)
            if (appName.isNotBlank()) {
                return AppCommand(AppCommand.OPEN_APP, mapOf("app_name" to appName))
            }
        }

        return null
    }

    private fun extractPrimeIndex(text: String): Int {
        return when {
            text.contains("second") || text.contains("dusra") -> 1
            text.contains("third") || text.contains("teesra") -> 2
            text.contains("fourth") || text.contains("chautha") -> 3
            else -> 0
        }
    }

    /** Strips known trigger words to isolate the app name, e.g. "YouTube kholo" -> "youtube". */
    private fun extractAppName(text: String, triggerWords: List<String>): String {
        var cleaned = text
        for (w in triggerWords) cleaned = cleaned.replace(w, " ")
        return cleaned.trim().trim('.', '!', '?')
    }

    /** Strips trigger words and "ko"/"to" connector to isolate a contact name. */
    private fun extractName(text: String, triggerWords: List<String>): String {
        var cleaned = text
        for (w in triggerWords) cleaned = cleaned.replace(w, " ")
        cleaned = cleaned.replace(Regex("\\bko\\b"), " ")
            .replace(Regex("\\bto\\b"), " ")
        return cleaned.trim().trim('.', '!', '?')
    }

    /** Best-effort extraction of message content after "ki taraf" / "saying" / "ki bolo" patterns. */
    private fun extractMessageBody(text: String): String {
        val markers = listOf(" bolo ", " likh ", " saying ", " ki taraf ", " message ")
        for (m in markers) {
            val idx = text.indexOf(m)
            if (idx != -1) return text.substring(idx + m.length).trim()
        }
        return ""
    }
}
