package com.myra.assistant.ai

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Manages the WebSocket connection to the Gemini Live "BidiGenerateContent" endpoint.
 * Handles setup, keepalive, session renewal (9 min) and reconnect (3s delay), mirroring
 * the reference Python client behaviour.
 */
class GeminiLiveClient(
    private var apiKey: String,
    private var model: String = DEFAULT_MODEL,
    private var voiceName: String = "Aoede",
    private var systemPrompt: String = ""
) {

    companion object {
        private const val TAG = "GeminiLiveClient"
        const val DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
        private const val WS_BASE =
            "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
        private const val SESSION_RENEW_AFTER_MS = 540_000L // 9 minutes
        private const val KEEPALIVE_INTERVAL_MS = 8_000L
        private const val RECONNECT_DELAY_MS = 3_000L
    }

    // Callbacks wired by MainActivity
    var onConnected: (() -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null
    var onSetupComplete: (() -> Unit)? = null
    var onAudioReceived: ((ByteArray) -> Unit)? = null
    var onInputTranscript: ((String) -> Unit)? = null
    var onOutputTranscript: ((String) -> Unit)? = null
    var onTurnComplete: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    private var client: OkHttpClient? = null
    private var webSocket: WebSocket? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var keepAliveJob: Job? = null
    private var renewJob: Job? = null
    private var shouldRun = false
    private var isConnected = false

    fun updateConfig(apiKey: String, model: String, voiceName: String, systemPrompt: String) {
        this.apiKey = apiKey
        this.model = model
        this.voiceName = voiceName
        this.systemPrompt = systemPrompt
    }

    fun connect() {
        shouldRun = true
        openSocket()
    }

    private fun openSocket() {
        if (client == null) {
            client = OkHttpClient.Builder()
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .pingInterval(20, TimeUnit.SECONDS)
                .build()
        }
        val url = "$WS_BASE?key=$apiKey"
        val request = Request.Builder().url(url).build()
        webSocket = client!!.newWebSocket(request, listener)
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d(TAG, "WebSocket opened")
            isConnected = true
            sendSetupMessage()
            startKeepAlive()
            startSessionRenewTimer()
            onConnected?.invoke()
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            handleServerMessage(text)
        }

        override fun onMessage(webSocket: WebSocket, bytes: okio.ByteString) {
            handleServerMessage(bytes.utf8())
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WebSocket failure: ${t.message}")
            isConnected = false
            onError?.invoke(t.message ?: "Unknown WebSocket error")
            onDisconnected?.invoke()
            scheduleReconnect()
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            Log.d(TAG, "WebSocket closed: $code $reason")
            isConnected = false
            onDisconnected?.invoke()
            scheduleReconnect()
        }
    }

    private fun scheduleReconnect() {
        stopTimers()
        if (!shouldRun) return
        scope.launch {
            delay(RECONNECT_DELAY_MS)
            if (shouldRun) openSocket()
        }
    }

    private fun sendSetupMessage() {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", model)
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
                })
                put("generation_config", JSONObject().apply {
                    put("response_modalities", JSONArray().put("AUDIO"))
                    put("speech_config", JSONObject().apply {
                        put("voice_config", JSONObject().apply {
                            put("prebuilt_voice_config", JSONObject().apply {
                                put("voice_name", voiceName)
                            })
                        })
                    })
                    put("temperature", 0.9)
                })
                put("output_audio_transcription", JSONObject())
                put("input_audio_transcription", JSONObject())
            })
        }
        webSocket?.send(setup.toString())
    }

    /** Send a chunk of 16kHz mono PCM16 mic audio. */
    fun sendAudioChunk(pcmBytes: ByteArray) {
        if (!isConnected) return
        val b64 = Base64.encodeToString(pcmBytes, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtime_input", JSONObject().apply {
                put("media_chunks", JSONArray().put(JSONObject().apply {
                    put("mime_type", "audio/pcm;rate=16000")
                    put("data", b64)
                }))
            })
        }
        webSocket?.send(msg.toString())
    }

    /** Send a text message to MYRA (used for greetings, call announcements, command results). */
    fun sendText(message: String) {
        if (!isConnected) return
        val msg = JSONObject().apply {
            put("client_content", JSONObject().apply {
                put("turns", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", message)))
                }))
                put("turn_complete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    /** Interrupt MYRA mid-speech (long-press mic). */
    fun sendInterrupt() {
        if (!isConnected) return
        val msg = JSONObject().apply {
            put("client_content", JSONObject().apply {
                put("turns", JSONArray())
                put("turn_complete", true)
            })
        }
        webSocket?.send(msg.toString())
    }

    private fun handleServerMessage(text: String) {
        try {
            val json = JSONObject(text)

            if (json.has("setupComplete")) {
                onSetupComplete?.invoke()
                return
            }

            val serverContent = json.optJSONObject("serverContent") ?: return

            val modelTurn = serverContent.optJSONObject("modelTurn")
            modelTurn?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    val data = inlineData?.optString("data")
                    if (!data.isNullOrEmpty()) {
                        val audioBytes = Base64.decode(data, Base64.NO_WRAP)
                        onAudioReceived?.invoke(audioBytes)
                    }
                }
            }

            serverContent.optJSONObject("outputTranscription")?.optString("text")?.let {
                if (it.isNotEmpty()) onOutputTranscript?.invoke(it)
            }

            serverContent.optJSONObject("inputTranscription")?.optString("text")?.let {
                if (it.isNotEmpty()) onInputTranscript?.invoke(it)
            }

            if (serverContent.optBoolean("turnComplete", false)) {
                onTurnComplete?.invoke()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse server message: ${e.message}")
        }
    }

    private fun startKeepAlive() {
        keepAliveJob?.cancel()
        keepAliveJob = scope.launch {
            while (isActive && isConnected) {
                delay(KEEPALIVE_INTERVAL_MS)
                // Send a silent PCM chunk to keep the connection alive
                val silence = ByteArray(1024)
                sendAudioChunk(silence)
            }
        }
    }

    private fun startSessionRenewTimer() {
        renewJob?.cancel()
        renewJob = scope.launch {
            delay(SESSION_RENEW_AFTER_MS)
            Log.d(TAG, "Renewing session after 9 minutes")
            disconnect(keepRunning = true)
            delay(500)
            if (shouldRun) openSocket()
        }
    }

    private fun stopTimers() {
        keepAliveJob?.cancel()
        renewJob?.cancel()
    }

    fun disconnect(keepRunning: Boolean = false) {
        shouldRun = keepRunning
        stopTimers()
        webSocket?.close(1000, "Client disconnect")
        webSocket = null
        isConnected = false
    }

    fun isActive(): Boolean = isConnected
}
