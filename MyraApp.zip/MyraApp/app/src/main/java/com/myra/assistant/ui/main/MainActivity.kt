package com.myra.assistant.ui.main

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.format.DateFormat
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.myra.assistant.R
import com.myra.assistant.ai.AudioEngine
import com.myra.assistant.ai.CommandParser
import com.myra.assistant.ai.GeminiLiveClient
import com.myra.assistant.databinding.ActivityMainBinding
import com.myra.assistant.model.ChatMessage
import com.myra.assistant.service.CallMonitorService
import com.myra.assistant.service.MyraOverlayService
import com.myra.assistant.ui.settings.SettingsActivity
import com.myra.assistant.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private var geminiLive: GeminiLiveClient? = null
    private var audioEngine: AudioEngine? = null
    private var chatAdapter: ChatAdapter = ChatAdapter()

    private var isMuted = false
    private var isInCallMode = false
    private var speechRecognizer: SpeechRecognizer? = null

    private var inputBuffer = StringBuilder()
    private var outputBuffer = StringBuilder()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val statusUpdateRunnable = object : Runnable {
        override fun run() {
            updateStatusBar()
            mainHandler.postDelayed(this, 30_000)
        }
    }

    private val callEndedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            setActiveMode(false)
            isInCallMode = false
        }
    }

    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ANSWER_PHONE_CALLS,
        Manifest.permission.CAMERA
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        initViews()
        checkPermissions()
        startSystemServices()
        startStatusUpdates()
        registerReceiver(callEndedReceiver, IntentFilter(CallMonitorService.ACTION_CALL_ENDED))

        mainHandler.postDelayed({ initGeminiLive() }, 300)

        handleIncomingCallIntent(intent)

        viewModel.commandResult.observe(this) { result ->
            if (result != null) {
                geminiLive?.sendText(result)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingCallIntent(intent)
    }

    private fun initViews() {
        binding.chatRecycler.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.chatRecycler.adapter = chatAdapter

        binding.settingsBtn.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        var pressStartTime = 0L
        val longPressThreshold = 500L

        binding.micButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    pressStartTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val pressDuration = System.currentTimeMillis() - pressStartTime
                    if (pressDuration >= longPressThreshold) {
                        onMicLongPress()
                    } else {
                        onMicTap()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun onMicTap() {
        isMuted = !isMuted
        audioEngine?.setMuted(isMuted)
        binding.micButton.setImageResource(if (isMuted) R.drawable.ic_mic_off else R.drawable.ic_mic_on)
        binding.statusText.text = if (isMuted) "Muted" else "Sun rahi hoon..."
    }

    private fun onMicLongPress() {
        // Interrupt MYRA mid-sentence
        audioEngine?.clearPlaybackQueue()
        geminiLive?.sendInterrupt()
        binding.orbView.setState(OrbAnimationView.OrbState.LISTENING)
        binding.statusText.text = "Sun rahi hoon..."
    }

    private fun checkPermissions() {
        val missing = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
        }
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    private fun startSystemServices() {
        val overlayIntent = Intent(this, MyraOverlayService::class.java)
        val callIntent = Intent(this, CallMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(callIntent)
        } else {
            startService(callIntent)
        }
    }

    private fun startStatusUpdates() {
        mainHandler.post(statusUpdateRunnable)
    }

    private fun updateStatusBar() {
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val batteryPct = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        binding.batteryText.text = "$batteryPct%"

        val runtime = Runtime.getRuntime()
        val usedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        binding.ramText.text = "${usedMb}MB"

        val timeFormat = if (DateFormat.is24HourFormat(this)) "HH:mm" else "hh:mm a"
        binding.timeText.text = SimpleDateFormat(timeFormat, Locale.getDefault()).format(Date())
    }

    // ---------- Gemini Live setup ----------

    private fun initGeminiLive() {
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        val userName = prefs.getString("user_name", "Boss") ?: "Boss"
        val personality = prefs.getString("personality_mode", "GF") ?: "GF"
        val model = prefs.getString("gemini_model", GeminiLiveClient.DEFAULT_MODEL) ?: GeminiLiveClient.DEFAULT_MODEL
        val voice = prefs.getString("gemini_voice", "Aoede") ?: "Aoede"

        if (apiKey.isBlank()) {
            binding.statusText.text = "API key set karo Settings mein"
            return
        }

        val systemPrompt = buildSystemPrompt(userName, personality)

        geminiLive = GeminiLiveClient(apiKey, model, voice, systemPrompt)
        audioEngine = AudioEngine(this)

        wireCallbacks(userName, personality)
        geminiLive?.connect()
    }

    private fun buildSystemPrompt(userName: String, personality: String): String {
        val now = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        val personalityBlock = when (personality) {
            "Professional" -> "Tone: Formal English only, precise and efficient, no emojis, max 2 sentences."
            "Assistant" -> "Tone: Friendly Hinglish or English, balanced and helpful, max 2-3 sentences."
            else -> "Tone: Warm, caring, emotionally expressive Hinglish (Hindi+English mix). Use words like 'tumhara', 'haan', 'acha', 'bilkul'. Max 2-3 sentences."
        }
        return """
            You are MYRA, an AI companion speaking to $userName.
            Current date/time: $now
            $personalityBlock
            You are speaking ALOUD — keep responses natural and conversational.
        """.trimIndent()
    }

    private fun wireCallbacks(userName: String, personality: String) {
        geminiLive?.onConnected = {
            runOnUiThread { binding.statusText.text = "Connected" }
        }

        geminiLive?.onSetupComplete = {
            runOnUiThread {
                audioEngine?.startRecording()
                audioEngine?.startPlayback()
                mainHandler.postDelayed({ sendGreeting(userName, personality) }, 600)
            }
        }

        geminiLive?.onDisconnected = {
            runOnUiThread { binding.statusText.text = "Reconnecting..." }
        }

        geminiLive?.onAudioReceived = { audioBytes ->
            audioEngine?.queueAudio(audioBytes)
        }

        geminiLive?.onInputTranscript = { text ->
            inputBuffer.append(text)
        }

        geminiLive?.onOutputTranscript = { text ->
            outputBuffer.append(text)
        }

        geminiLive?.onTurnComplete = {
            runOnUiThread { flushTranscriptBuffers() }
        }

        geminiLive?.onError = { message ->
            runOnUiThread { Toast.makeText(this, "MYRA: $message", Toast.LENGTH_SHORT).show() }
        }

        audioEngine?.onMicChunk = { chunk ->
            if (!isInCallMode) geminiLive?.sendAudioChunk(chunk)
        }

        audioEngine?.onAmplitudeChanged = { rms ->
            runOnUiThread {
                binding.waveformView.setAmplitude(rms)
                binding.orbView.setAmplitude(rms)
            }
        }

        audioEngine?.onSpeakingStarted = {
            runOnUiThread {
                binding.orbView.setState(OrbAnimationView.OrbState.SPEAKING)
                binding.statusText.text = "Bol rahi hoon..."
                animateRedOverlay(true)
            }
        }

        audioEngine?.onSpeakingStopped = {
            runOnUiThread {
                binding.orbView.setState(OrbAnimationView.OrbState.LISTENING)
                binding.statusText.text = "Sun rahi hoon..."
                animateRedOverlay(false)
            }
        }
    }

    private fun sendGreeting(userName: String, personality: String) {
        val greeting = when (personality) {
            "Professional" -> "Good day $userName. MYRA is online and ready to assist you."
            "Assistant" -> "Hello $userName! Main MYRA hoon. Kaise help karun aapki?"
            else -> "Hey $userName! Main aa gayi hoon. Kya help chahiye tumhe?"
        }
        geminiLive?.sendText(greeting)
    }

    private fun flushTranscriptBuffers() {
        val userText = inputBuffer.toString().trim()
        val myraText = outputBuffer.toString().trim()

        if (userText.isNotEmpty()) {
            chatAdapter.addMessage(ChatMessage(userText, isUser = true))

            // Parse for local phone commands
            val command = CommandParser.parse(userText)
            if (command != null) {
                viewModel.execute(command)
            }
        }
        if (myraText.isNotEmpty()) {
            chatAdapter.addMessage(ChatMessage(myraText, isUser = false))
        }

        binding.chatRecycler.scrollToPosition(chatAdapter.itemCount - 1)
        inputBuffer.clear()
        outputBuffer.clear()
    }

    private fun animateRedOverlay(active: Boolean) {
        val target = if (active) 0.08f else 0f
        val duration = if (active) 300L else 500L
        binding.redOverlay.animate().alpha(target).setDuration(duration).start()
    }

    private fun setActiveMode(active: Boolean) {
        binding.orbView.setState(if (active) OrbAnimationView.OrbState.ACTIVE else OrbAnimationView.OrbState.IDLE)
    }

    // ---------- Incoming call handling ----------

    private fun handleIncomingCallIntent(intent: Intent?) {
        val isIncoming = intent?.getBooleanExtra(CallMonitorService.EXTRA_INCOMING_CALL, false) ?: false
        if (isIncoming) {
            val callerName = intent?.getStringExtra(CallMonitorService.EXTRA_CALLER_NAME) ?: "Unknown"
            announceCall(callerName)
        }
    }

    private fun announceCall(callerName: String) {
        isInCallMode = true
        val message = "Sir, $callerName ka call aa raha hai. Uthau ya reject karu?"
        geminiLive?.sendText(message)
        binding.orbView.setState(OrbAnimationView.OrbState.SPEAKING)
        binding.statusText.text = "Call announce kar rahi hoon..."

        mainHandler.postDelayed({ startCallDecisionListening() }, 4500)
    }

    private fun startCallDecisionListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val decision = matches?.firstOrNull()?.lowercase() ?: ""
                handleCallDecision(decision)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun handleCallDecision(decision: String) {
        val accept = listOf("uthao", "haan", "accept", "receive").any { decision.contains(it) }
        val reject = listOf("reject", "nahi", "mat", "decline").any { decision.contains(it) }

        val resultMessage = when {
            accept -> viewModel.acceptCall()
            reject -> viewModel.rejectCall()
            else -> "Samajh nahi aaya, phir se bolo."
        }

        geminiLive?.sendText(resultMessage)
        speechRecognizer?.destroy()
        speechRecognizer = null

        if (accept || reject) {
            setActiveMode(false)
        }
    }

    // ---------- Lifecycle ----------

    override fun onPause() {
        super.onPause()
        audioEngine?.setMuted(true)
    }

    override fun onResume() {
        super.onResume()
        if (!isMuted) audioEngine?.setMuted(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        geminiLive?.disconnect()
        audioEngine?.release()
        mainHandler.removeCallbacks(statusUpdateRunnable)
        unregisterReceiver(callEndedReceiver)
        speechRecognizer?.destroy()
    }
}
