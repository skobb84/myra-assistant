package com.myra.assistant.ui.main

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class OrbAnimationView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class OrbState { IDLE, LISTENING, SPEAKING, THINKING, ACTIVE }

    private var state = OrbState.IDLE
    private var amplitude = 0f

    private var pulseScale = 1f
    private var rotationAngle = 0f
    private var waveOffset = 0f
    private var thinkingAngle = 0f
    private var glowAlpha = 120

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var pulseAnimator: ValueAnimator? = null
    private var rotateAnimator: ValueAnimator? = null
    private var waveAnimator: ValueAnimator? = null
    private var thinkAnimator: ValueAnimator? = null

    init {
        startPulseAnimation()
        startRotateAnimation()
        startWaveAnimation()
    }

    fun setState(newState: OrbState) {
        state = newState
        if (newState == OrbState.THINKING) startThinkingAnimation() else thinkAnimator?.cancel()
        invalidate()
    }

    fun setAmplitude(rms: Float) {
        amplitude = rms.coerceIn(0f, 1f)
    }

    private fun startPulseAnimation() {
        pulseAnimator = ValueAnimator.ofFloat(1f, 1.15f, 1f).apply {
            duration = 1500
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulseScale = it.animatedValue as Float
                glowAlpha = (120 + (it.animatedFraction * 100)).toInt().coerceIn(120, 220)
                invalidate()
            }
            start()
        }
    }

    private fun startRotateAnimation() {
        rotateAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 4000
            repeatCount = ValueAnimator.INFINITE
            interpolator = null
            addUpdateListener {
                rotationAngle = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun startWaveAnimation() {
        waveAnimator = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
            duration = 2000
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                waveOffset = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun startThinkingAnimation() {
        thinkAnimator?.cancel()
        thinkAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                thinkingAngle = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = (minOf(width, height) / 2f) * 0.55f

        val (colorStart, colorEnd) = colorsForState()

        // 1. Radial glow
        glowPaint.shader = RadialGradient(
            cx, cy, baseRadius * 1.6f,
            intArrayOf(adjustAlpha(colorStart, glowAlpha), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius * 1.6f, glowPaint)

        // 2. Core orb (sphere illusion)
        val radius = baseRadius * pulseScale * (1f + amplitude * 0.15f)
        corePaint.shader = RadialGradient(
            cx - radius * 0.3f, cy - radius * 0.3f, radius * 1.3f,
            intArrayOf(colorEnd, colorStart),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, corePaint)

        // 3. Rotating rings
        if (state == OrbState.LISTENING || state == OrbState.ACTIVE || state == OrbState.SPEAKING) {
            ringPaint.color = colorStart
            for (i in 0 until 3) {
                val ringRadius = radius * (1.1f + i * 0.15f)
                canvas.save()
                canvas.rotate(rotationAngle + i * 40f, cx, cy)
                canvas.drawArc(
                    cx - ringRadius, cy - ringRadius, cx + ringRadius, cy + ringRadius,
                    0f, 120f, false, ringPaint
                )
                canvas.restore()
            }
        }

        // 4. Wave rings (sine, amplitude-reactive)
        wavePaint.color = adjustAlpha(colorEnd, 160)
        val waveRadius = radius * 1.3f + (sin(waveOffset) * 6f) + (amplitude * 20f)
        canvas.drawCircle(cx, cy, waveRadius, wavePaint)

        // 5. Thinking arc
        if (state == OrbState.THINKING) {
            ringPaint.color = colorStart
            canvas.save()
            canvas.rotate(thinkingAngle, cx, cy)
            canvas.drawArc(
                cx - radius * 1.2f, cy - radius * 1.2f, cx + radius * 1.2f, cy + radius * 1.2f,
                0f, 100f, false, ringPaint
            )
            canvas.rotate(180f, cx, cy)
            canvas.drawArc(
                cx - radius * 1.2f, cy - radius * 1.2f, cx + radius * 1.2f, cy + radius * 1.2f,
                0f, 100f, false, ringPaint
            )
            canvas.restore()
        }

        // 6. Orbiting particles
        if (state == OrbState.ACTIVE || state == OrbState.SPEAKING) {
            particlePaint.color = colorEnd
            for (i in 0 until 12) {
                val angle = Math.toRadians((rotationAngle + i * 30f).toDouble())
                val px = cx + (radius * 1.5f * cos(angle)).toFloat()
                val py = cy + (radius * 1.5f * sin(angle)).toFloat()
                canvas.drawCircle(px, py, 3f, particlePaint)
            }
        }

        // 7. Inner highlight
        highlightPaint.shader = RadialGradient(
            cx - radius * 0.35f, cy - radius * 0.35f, radius * 0.5f,
            intArrayOf(Color.argb(160, 255, 255, 255), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx - radius * 0.3f, cy - radius * 0.3f, radius * 0.4f, highlightPaint)
    }

    private fun colorsForState(): Pair<Int, Int> {
        return when (state) {
            OrbState.IDLE -> Color.parseColor("#B71C1C") to Color.parseColor("#880E4F")
            OrbState.LISTENING, OrbState.ACTIVE -> Color.parseColor("#FF1744") to Color.parseColor("#D500F9")
            OrbState.SPEAKING -> Color.parseColor("#E040FB") to Color.parseColor("#FF1744")
            OrbState.THINKING -> Color.parseColor("#40C4FF") to Color.parseColor("#00B0FF")
        }
    }

    private fun adjustAlpha(color: Int, alpha: Int): Int {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        pulseAnimator?.cancel()
        rotateAnimator?.cancel()
        waveAnimator?.cancel()
        thinkAnimator?.cancel()
    }
}
