package com.myra.assistant.ui.main

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.myra.assistant.R
import com.myra.assistant.model.ChatMessage
import java.text.SimpleDateFormat
import java.util.*

/** 20-bar amplitude-reactive waveform, mirrors mic/speaker RMS via [setAmplitude]. */
class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        private const val BAR_COUNT = 20
    }

    private val barHeights = FloatArray(BAR_COUNT) { 0.1f }
    private val targetHeights = FloatArray(BAR_COUNT) { 0.1f }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var animating = false
    private val random = Random()

    private val updateRunnable = object : Runnable {
        override fun run() {
            if (!animating) return
            for (i in 0 until BAR_COUNT) {
                barHeights[i] += (targetHeights[i] - barHeights[i]) * 0.3f
            }
            invalidate()
            postDelayed(this, 40)
        }
    }

    fun startAnimation() {
        animating = true
        post(updateRunnable)
    }

    fun stopAnimation() {
        animating = false
        removeCallbacks(updateRunnable)
        for (i in 0 until BAR_COUNT) targetHeights[i] = 0.1f
    }

    fun setAmplitude(rms: Float) {
        val clamped = rms.coerceIn(0f, 1f)
        for (i in 0 until BAR_COUNT) {
            // Each bar gets a slightly randomized share of the amplitude for a natural look
            targetHeights[i] = (clamped * (0.4f + random.nextFloat() * 0.6f)).coerceIn(0.05f, 1f)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val barWidth = width.toFloat() / (BAR_COUNT * 1.6f)
        val gap = barWidth * 0.6f
        var x = gap / 2

        for (i in 0 until BAR_COUNT) {
            val h = barHeights[i] * height
            val alpha = (150 + (barHeights[i] * 105)).toInt().coerceIn(150, 255)
            paint.color = Color.argb(alpha, 255, 23, 68) // #FF1744 with variable alpha
            val top = (height - h) / 2
            canvas.drawRoundRect(x, top, x + barWidth, top + h, 4f, 4f, paint)
            x += barWidth + gap
        }
    }
}

/** RecyclerView adapter for MYRA's chat transcript. */
class ChatAdapter(private val messages: MutableList<ChatMessage> = mutableListOf()) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_MYRA = 1
    }

    fun addMessage(message: ChatMessage) {
        // Deduplication: skip if last MYRA message is identical to the new one
        if (!message.isUser && lastMyraText() == message.text) return
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    fun lastMyraText(): String? {
        return messages.lastOrNull { !it.isUser }?.text
    }

    override fun getItemViewType(position: Int): Int {
        return if (messages[position].isUser) TYPE_USER else TYPE_MYRA
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val layoutRes = if (viewType == TYPE_USER) R.layout.item_chat_user else R.layout.item_chat_myra
        val view = inflater.inflate(layoutRes, parent, false)
        return object : RecyclerView.ViewHolder(view) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        val textView = holder.itemView.findViewById<TextView>(R.id.chatMessageText)
        textView?.text = message.text
        val timeView = holder.itemView.findViewById<TextView>(R.id.chatMessageTime)
        timeView?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
    }

    override fun getItemCount(): Int = messages.size
}
