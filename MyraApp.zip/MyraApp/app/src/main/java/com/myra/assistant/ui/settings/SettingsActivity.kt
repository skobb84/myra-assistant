package com.myra.assistant.ui.settings

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.lifecycle.ViewModelProvider
import com.myra.assistant.R
import com.myra.assistant.databinding.ActivitySettingsBinding
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.service.AccessibilityHelperService
import com.myra.assistant.viewmodel.MainViewModel

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var primeContactAdapter: PrimeContactAdapter
    private val primeContacts = mutableListOf<PrimeContact>()

    private val modelOptions = listOf(
        "Native Audio (Human Voice)" to "models/gemini-2.5-flash-native-audio-preview-12-2025",
        "Flash Live (Fast)" to "models/gemini-2.0-flash-live-001",
        "Pro Audio Dialog" to "models/gemini-2.5-flash-preview-native-audio-dialog"
    )

    private val voiceOptions = listOf(
        "Aoede (Female)" to "Aoede", "Charon (Male)" to "Charon", "Kore (Female)" to "Kore",
        "Fenrir (Male)" to "Fenrir", "Puck (Male)" to "Puck", "Leda (Female)" to "Leda",
        "Orus (Male)" to "Orus", "Zephyr (Female)" to "Zephyr"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        setupSpinners()
        setupPrimeContacts()
        loadPrefs()

        binding.saveButton.setOnClickListener { savePrefs() }
        binding.accessibilityStatus.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.addPrimeContactButton.setOnClickListener { showAddPrimeContactDialog() }
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
    }

    private fun setupSpinners() {
        binding.modelSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, modelOptions.map { it.first }
        )
        binding.voiceSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, voiceOptions.map { it.first }
        )
    }

    private fun setupPrimeContacts() {
        primeContactAdapter = PrimeContactAdapter(primeContacts) { position ->
            primeContacts.removeAt(position)
            primeContactAdapter.notifyItemRemoved(position)
        }
        binding.primeContactsRecycler.layoutManager = LinearLayoutManager(this)
        binding.primeContactsRecycler.adapter = primeContactAdapter
    }

    private fun loadPrefs() {
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        binding.apiKeyInput.setText(prefs.getString("api_key", ""))
        binding.userNameInput.setText(prefs.getString("user_name", ""))

        val savedModel = prefs.getString("gemini_model", modelOptions[0].second)
        val modelIndex = modelOptions.indexOfFirst { it.second == savedModel }.takeIf { it >= 0 } ?: 0
        binding.modelSpinner.setSelection(modelIndex)

        val savedVoice = prefs.getString("gemini_voice", "Aoede")
        val voiceIndex = voiceOptions.indexOfFirst { it.second == savedVoice }.takeIf { it >= 0 } ?: 0
        binding.voiceSpinner.setSelection(voiceIndex)

        when (prefs.getString("personality_mode", "GF")) {
            "Professional" -> binding.personalityGroup.check(R.id.radioProfessional)
            "Assistant" -> binding.personalityGroup.check(R.id.radioAssistant)
            else -> binding.personalityGroup.check(R.id.radioGf)
        }

        primeContacts.clear()
        primeContacts.addAll(viewModel.getPrimeContacts())
        primeContactAdapter.notifyDataSetChanged()

        updateAccessibilityStatus()
    }

    private fun savePrefs() {
        val prefs = getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val personality = when (binding.personalityGroup.checkedRadioButtonId) {
            R.id.radioProfessional -> "Professional"
            R.id.radioAssistant -> "Assistant"
            else -> "GF"
        }

        prefs.edit()
            .putString("api_key", binding.apiKeyInput.text.toString())
            .putString("user_name", binding.userNameInput.text.toString())
            .putString("gemini_model", modelOptions[binding.modelSpinner.selectedItemPosition].second)
            .putString("gemini_voice", voiceOptions[binding.voiceSpinner.selectedItemPosition].second)
            .putString("personality_mode", personality)
            .apply()

        viewModel.savePrimeContacts(primeContacts)

        Toast.makeText(this, "Restart app to apply changes", Toast.LENGTH_LONG).show()
    }

    private fun showAddPrimeContactDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_prime_contact, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.dialogNameInput)
        val numberInput = dialogView.findViewById<EditText>(R.id.dialogNumberInput)

        AlertDialog.Builder(this)
            .setTitle("Add Prime Contact")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = nameInput.text.toString().trim()
                val number = numberInput.text.toString().trim()
                if (name.isNotEmpty() && number.isNotEmpty()) {
                    primeContacts.add(PrimeContact(name, number))
                    primeContactAdapter.notifyItemInserted(primeContacts.size - 1)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updateAccessibilityStatus() {
        val enabled = AccessibilityHelperService.isEnabled(this)
        binding.accessibilityStatus.text = if (enabled) "Accessibility: ON ✅" else "Accessibility: OFF ❌"
    }
}

/** Adapter for the prime contacts RecyclerView in Settings. */
class PrimeContactAdapter(
    private val contacts: List<PrimeContact>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PrimeContactAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.primeItemName)
        val number: TextView = view.findViewById(R.id.primeItemNumber)
        val delete: ImageButton = view.findViewById(R.id.primeItemDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_prime_contact, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val contact = contacts[position]
        holder.name.text = contact.name
        holder.number.text = contact.number
        holder.delete.setOnClickListener { onDelete(holder.adapterPosition) }
    }

    override fun getItemCount(): Int = contacts.size
}
