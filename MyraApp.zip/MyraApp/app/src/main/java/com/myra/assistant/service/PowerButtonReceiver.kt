package com.myra.assistant.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock

/**
 * Listens for SCREEN_OFF / SCREEN_ON broadcasts and detects a "double power press"
 * (two SCREEN_OFF+SCREEN_ON cycles within 600ms) to trigger the floating orb overlay.
 */
class PowerButtonReceiver : BroadcastReceiver() {

    companion object {
        private const val DOUBLE_PRESS_WINDOW_MS = 600L
        private var lastScreenOffTime = 0L
        private var screenOffCount = 0
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_SCREEN_OFF -> {
                val now = SystemClock.elapsedRealtime()
                if (now - lastScreenOffTime <= DOUBLE_PRESS_WINDOW_MS * 3) {
                    screenOffCount++
                } else {
                    screenOffCount = 1
                }
                lastScreenOffTime = now

                if (screenOffCount >= 2) {
                    screenOffCount = 0
                    triggerOverlay(context)
                }
            }
            Intent.ACTION_SCREEN_ON -> {
                // Screen-on events help bound the double-press window; no action needed here.
            }
        }
    }

    private fun triggerOverlay(context: Context) {
        val serviceIntent = Intent(context, MyraOverlayService::class.java).apply {
            action = MyraOverlayService.ACTION_SHOW_OVERLAY
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }
}
