package com.myra.assistant

import android.app.Application

class MyraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
